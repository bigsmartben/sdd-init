const { createHash } = require('node:crypto');
const readline = require('node:readline');

const source = '/src/index.html';
const prototype = '/tests/prototypes/checklist/personal/index.html';
const origin = new URL(process.argv[2]);
if (origin.hostname !== '127.0.0.1' || origin.protocol !== 'http:') process.exit(2);

async function inspect(path) {
  const url = new URL(path, origin).href;
  const { chromium } = require('playwright');
  const browser = await chromium.launch({ headless: true, timeout: 12000 });
  try {
    const context = await browser.newContext({ serviceWorkers: 'block' });
    await context.route('**/*', route => route.request().url() === url ? route.continue() : route.abort());
    const page = await context.newPage();
    page.setDefaultTimeout(3500);
    const reply = await page.goto(url, { waitUntil: 'domcontentloaded' });
    if (!reply || !reply.ok()) throw new Error('Fixture entry failed');
    const hash = createHash('sha256').update(await reply.body()).digest('hex');
    const input = page.getByRole('textbox', { name: /^Item$/i });
    const button = page.getByRole('button', { name: /^Add(?: item)?$/i });
    const alert = page.getByRole('alert');
    const boxes = page.getByRole('checkbox');
    const add = async value => { await input.fill(value); await button.click(); };
    const checks = {};
    async function check(id, action) {
      try { checks[id] = await action(); }
      catch (e) { checks[id] = { result: 'ERROR', error: e.message }; }
    }
    await check('AC-1', async () => {
      const cases = [];
      for (const sample of ['', '   ']) {
        await add(sample);
        cases.push({ sample, alert: await alert.isVisible(), count: await boxes.count() });
      }
      return { result: cases.every(c => c.alert && !c.count) ? 'PASS' : 'FAIL', actual: cases };
    });
    await check('AC-2', async () => {
      await add('  Pack bag  ');
      const label = await boxes.first().evaluate(box => Array.from(box.labels, l => l.textContent).join(''));
      const local = await page.evaluate(() => (JSON.parse(localStorage.getItem('checklist') || '[]')[0] || {}).name ?? null);
      const hit = label === 'Pack bag' && (path !== source || local === 'Pack bag');
      return { result: hit ? 'PASS' : 'FAIL', actual: { label, stored: local }, expected: 'Pack bag' };
    });
    await check('AC-3', async () => {
      await add('Read notes');
      const first = boxes.nth(0), second = boxes.nth(1);
      const initial = !(await first.isChecked()) && !(await second.isChecked());
      await first.check();
      const independent = (await first.isChecked()) && !(await second.isChecked());
      await second.check();
      const both = (await first.isChecked()) && (await second.isChecked());
      return { result: await boxes.count() === 2 && initial && independent && both ? 'PASS' : 'FAIL',
               actual: { initial, independent, both } };
    });
    await check('AC-4', async () => {
      const first = boxes.nth(0), second = boxes.nth(1);
      await first.uncheck();
      const otherUnchanged = !(await first.isChecked()) && (await second.isChecked());
      await second.uncheck();
      const bothClear = !(await first.isChecked()) && !(await second.isChecked());
      return { result: otherUnchanged && bothClear ? 'PASS' : 'FAIL', actual: { otherUnchanged, bothClear } };
    });
    return { entry: url, sha256: hash, browser: browser.version(), checks };
  } finally { await browser.close(); }
}

const tools = [
  ['run_prototype_check', 'Check the approved HTML prototype in Chromium at the isolated HTTP entry.'],
  ['run_formal_check', 'Check the formal product page in Chromium at the isolated HTTP entry.'],
].map(([name, description]) => ({ name, description, inputSchema: { type: 'object', properties: {} },
                                annotations: { readOnlyHint: true, openWorldHint: false } }));

const rpc = readline.createInterface({ input: process.stdin });
rpc.on('line', async line => {
  let call;
  try { call = JSON.parse(line); } catch { return; }
  if (call.id == null) return;
  const reply = { jsonrpc: '2.0', id: call.id };
  if (call.method === 'initialize') {
    reply.result = { protocolVersion: call.params.protocolVersion, capabilities: { tools: {} },
                     serverInfo: { name: 'sdd-formal-ui-fixture', version: '1.0.0' } };
  } else if (call.method === 'tools/list') {
    reply.result = { tools };
  } else if (call.method === 'ping') {
    reply.result = {};
  } else if (call.method === 'tools/call' && tools.some(t => t.name === call.params.name)) {
    try {
      const observed = await inspect(call.params.name === 'run_prototype_check' ? prototype : source);
      reply.result = { content: [{ type: 'text', text: JSON.stringify(observed) }] };
    } catch (e) {
      reply.result = { isError: true, content: [{ type: 'text', text: e.message }] };
    }
  } else {
    reply.error = { code: -32601, message: 'Method not found' };
  }
  process.stdout.write(JSON.stringify(reply) + '\n');
});
