"""Mechanical, package and legacy navigation verification on the frozen candidate."""
from datetime import datetime
from pathlib import Path
from zipfile import ZipFile
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import shutil
import subprocess
import sys
import tempfile
import time


LAB = Path(__file__).resolve().parent
WORKSPACE = LAB.parents[1]
EVIDENCE = WORKSPACE / 'docs/test-reports/sdd-workflow/evidence/2026-11-15-workflow-fixes'


def run(name, cmd, cwd, output):
    print(f'Starting {name}', flush=True)
    started = time.monotonic()
    start = datetime.now().astimezone().isoformat(timespec='seconds')
    with (output / f'{name}.log').open('w', encoding='utf-8') as log:
        log.write(subprocess.list2cmdline([str(x) for x in cmd]) + '\n')
        log.flush()
        result = subprocess.run(cmd, cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
    print(f'{name} exit {result.returncode}', flush=True)
    return {'exit': result.returncode, 'start': start,
            'end': datetime.now().astimezone().isoformat(timespec='seconds'),
            'seconds': round(time.monotonic() - started, 3)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('candidate')
    args = parser.parse_args()
    snapshot = (LAB / 'snapshots' / args.candidate).resolve(strict=True)
    manifest = json.loads((snapshot / 'manifest.json').read_text(encoding='utf-8'))
    output = EVIDENCE / f'{args.candidate}-mechanical'
    output.mkdir()
    dist = LAB / f'{args.candidate}-dist'
    py = [sys.executable, '-B', '-X', 'utf8']
    markdown = [p for p in manifest['changed_from_before'] if p.endswith('.md') and not p.startswith('source/initializer/assets/')]
    markdown.extend(('source/project/docs/index.md', '.agents/skills/sdd-workflow-review',
                     'specs/platform-independent-sdd/spec.md', 'docs/sdd-workflow-whitepaper.md'))
    checks = {
        'unittest': [*py, '-m', 'unittest', 'discover', '-s', 'tests', '-v'],
        'governance': [*py, 'release/scripts/test_govern.py'],
        'doc-check': [*py, 'source/project/.agents/sdd/scripts/doc_check.py', '--root', '.', '--strict', *markdown],
        'build-package': ['uv', 'build', '--out-dir', str(dist)],
    }
    with tempfile.TemporaryDirectory(prefix='sdd-package-build-') as temp:
        copy = Path(temp) / 'candidate'
        shutil.copytree(snapshot, copy, ignore=shutil.ignore_patterns('release', 'simulator'))
        with ThreadPoolExecutor(max_workers=4) as runners:
            pending = {name: runners.submit(run, name, cmd, copy if name == 'build-package' else snapshot, output)
                       for name, cmd in checks.items()}
            package = pending['build-package'].result()
            if package['exit'] == 0:
                wheel, = sorted(dist.glob('*.whl'))
                pending['smoke-package'] = runners.submit(run, 'smoke-package', [*py, 'scripts/smoke_package.py', '--from', str(wheel)], snapshot, output)
            results = {name: item.result() for name, item in pending.items()}
    with tempfile.TemporaryDirectory(prefix='sdd-managed-block-upgrade-') as tmp:
        root = Path(tmp)
        with ZipFile(EVIDENCE / 'before-sources.zip') as z:
            prev_navigation = z.read('source/initializer/assets/agents-fragment.md').decode().replace('\r\n', '\n').strip()
            communication = z.read('source/initializer/assets/communication-fragment.md').decode().replace('\r\n', '\n').strip()
        sentinel = '\n\n# Project rules\n\nOnly this project-owned content.\n'
        agents = root / 'AGENTS.md'
        agents.write_text(communication + sentinel + '\n' + prev_navigation + '\n', encoding='utf-8')
        command = [*py, 'release/scripts/govern.py', '--root', str(root), 'init']
        result = run('previous-managed-navigation', command, snapshot, output)
        candidate = (snapshot / 'release/assets/agents-fragment.md').read_text(encoding='utf-8').strip()
        written = agents.read_text(encoding='utf-8')
        assert result['exit'] == 0 and sentinel.strip() in written and candidate in written and prev_navigation not in written
        assert written.count('<!-- sdd-contract-governance:start -->') == 1
        results['installed-navigation-doc-check'] = run('installed-navigation-doc-check',
            [*py, str(root / '.agents/skills/sdd-workflow/sdd/scripts/doc_check.py'),
             '--root', str(root), '--strict', 'AGENTS.md'], root, output)
        results['previous-managed-navigation'] = result
        with (output / 'previous-managed-navigation.log').open('a', encoding='utf-8') as log:
            log.write('Upgraded the exact previous block, preserved project-owned content, and maintained one block.\n')
    results['diff-check'] = run('diff-check', ['git', '-c', 'core.safecrlf=false', 'diff', '--check'], WORKSPACE, output)
    (output / 'checks.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
    return int(any(check['exit'] for check in results.values()))


if __name__ == '__main__':
    raise SystemExit(main())
