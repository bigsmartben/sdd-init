"""Summarize per-case runtime metrics without conflating them with review usage."""
from collections import defaultdict
from datetime import datetime
from pathlib import Path
import argparse
import json


FIELDS = ('input_tokens', 'cached_input_tokens', 'output_tokens', 'reasoning_output_tokens', 'total_tokens')


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def for_case(run_file):
    run = load(run_file)
    streams = []
    main_id = run.get('main_session')
    primary = run_file.parent / 'events.jsonl'
    for p in [primary, *sorted(run_file.parent.glob('*/events.jsonl'))]:
        if not p.is_file():
            continue
        events = [json.loads(line) for line in p.read_text(encoding='utf-8').splitlines() if line.endswith('}')]
        for e in events:
            if e['type'] == 'thread.started' and p == primary:
                main_id = e['thread_id']
    for s in run['sessions']:
        identities = s['identities'] or [s['identity']]
        # A child log can contain the parent at log creation. Its own spawn metadata is authoritative.
        first = identities[0]
        own = [i for i in identities if i.get('id') != main_id
               and isinstance(i.get('source'), dict) and i['source'].get('subagent')]
        selected = own[-1] if own else first
        streams.append({'session': selected.get('id'), 'model': s['model'], 'role': selected.get('agent_role'),
                        'trace': s['trace'], 'usage': s['usage']})
    by_actor = defaultdict(list)
    for s in streams:
        by_actor[s['session']].append(s)
    missing = any(not actor or len(entries) != 1 or entries[0]['usage'] is None
                  for actor, entries in by_actor.items()) or not by_actor or main_id not in by_actor or run['exit'] != 0
    totals = {field: sum((entries[0]['usage'] or {}).get(field, 0)
                         for actor, entries in by_actor.items() if actor and len(entries) == 1) for field in FIELDS}
    if run.get('turns'):
        turns = [{k: t[k] for k in ('turn', 'metrics')} for t in run['turns']]
    else:
        turns = [{'turn': 'initial', 'metrics': {k: run[k] for k in ('start', 'end', 'seconds', 'exit')}}]
    return {'candidate': run['candidate'], 'start': run['start'], 'end': run['end'], 'exit': run['exit'],
            'main_session': main_id, 'sessions': streams, 'measured_usage_subtotal': totals,
            'coverage_complete': not missing, 'turns': turns,
            'wall_seconds_from_timestamps': (datetime.fromisoformat(run['end']) - datetime.fromisoformat(run['start'])).total_seconds()}


def get_scope(cases):
    closed = {k: v for k, v in cases.items() if v['coverage_complete']}
    start = min((v['start'] for v in cases.values()), default=None)
    end = max((v['end'] for v in cases.values()), default=None)
    return {'case_count': len(cases), 'complete_usage_cases': len(closed),
            'usage_with_complete_trace_only': {field: sum(v['measured_usage_subtotal'][field] for v in closed.values())
                                               for field in FIELDS},
            'start': start, 'end': end,
            'wall_seconds_across_cases': (datetime.fromisoformat(end) - datetime.fromisoformat(start)).total_seconds() if start else None}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('evidence', type=Path)
    args = parser.parse_args()
    cases = {p.parent.relative_to(args.evidence).as_posix(): for_case(p)
             for p in sorted(args.evidence.glob('*/*/run.json'))}
    cases.update({p.parent.relative_to(args.evidence).as_posix(): for_case(p)
                  for p in sorted(args.evidence.glob('final-cold-handoff*/*/*/stage.json'))})
    scopes = {'targeted': get_scope({k:v for k,v in cases.items() if k.startswith('targeted-')}),
              'final': get_scope({k:v for k,v in cases.items() if k.startswith('final-')})}
    active_status = {p.parent.relative_to(args.evidence).as_posix(): load(p)
                     for p in sorted(args.evidence.glob('final-active-status*/*/active-status.json'))}
    result = {'scope': 'retained model cases; source and loaded prompt token measures and Main review are separate',
              'method': 'Last cumulative usage per verified session. Cached input is part of input; reasoning is part of output. Incomplete streams are kept with their measured subtotal. Parallel case time is not added to wall time.',
              'testcase': scopes, 'cases': cases,
              'app_server_status_probes': {'usage': 'not measured by this export', 'runs': active_status}}
    (args.evidence / 'runtime-usage-and-versions.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(scopes, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
