"""Freeze the exact source and fixture inputs before building or running a batch."""
from hashlib import sha256
from pathlib import Path
import argparse
import json
import shutil
import subprocess
import sys


LAB = Path(__file__).resolve().parent
WORKSPACE = LAB.parents[1]
EVIDENCE = WORKSPACE / 'docs/test-reports/sdd-workflow/evidence/2026-11-15-workflow-fixes'
SIMULATOR = WORKSPACE / '.build/deliver-verification-20261114-__sqm5l8'


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def freeze(label):
    assert label.replace('-', '').isalnum() and label.isascii(), label
    snapshot = LAB / 'snapshots' / label
    snapshot.mkdir(parents=True)
    original = json.loads((EVIDENCE / 'before-manifest.json').read_text(encoding='utf-8'))
    paths = set(original['files'])
    for folder in ('source', 'tests', 'src', '.agents/skills/sdd-workflow-review', 'scripts'):
        paths.update(path.relative_to(WORKSPACE).as_posix() for path in (WORKSPACE / folder).rglob('*')
                     if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc'
                     and not any(part.endswith('.egg-info') for part in path.parts))
    paths.update(('pyproject.toml', 'setup.py', 'MANIFEST.in', 'docs/installation.md', 'docs/workflow-evidence.md',
                  'docs/test-reports/sdd-workflow/2026-11-14-whitepaper-assessment-archive.md'))
    files = {}
    for name in sorted(paths):
        path = WORKSPACE / name
        assert path.is_file() and not path.is_symlink(), name
        target = snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        files[name] = digest(target)
        assert files[name] == digest(path), f'concurrent input change: {name}'
    for name in original['tracked_missing']:
        assert not (WORKSPACE / name).exists(), name
    for name in ('behavior.py', 'ops-lab.py'):
        target = snapshot / 'simulator' / name
        target.parent.mkdir(exist_ok=True)
        shutil.copyfile(SIMULATOR / name, target)
    subprocess.run([sys.executable, '-B', str(snapshot / 'scripts/build_release.py'),
                    '--output', str(snapshot / 'release')], check=True)
    asset = snapshot / 'release/build-manifest.json'
    payload = {'label': label, 'head': original['head'], 'files': files,
               'tracked_missing': original['tracked_missing'],
               'release_manifest_sha256': digest(asset),
               'simulator': {p.name: digest(p) for p in sorted((snapshot / 'simulator').glob('*.py'))},
               'changed_from_before': {n: {'before': original['files'].get(n), 'after': h}
                                       for n, h in files.items() if n in original['files'] and original['files'][n] != h},
               'build_only_or_added': sorted(set(files).difference(original['files']))}
    dump(snapshot / 'manifest.json', payload)
    shutil.copyfile(snapshot / 'manifest.json', EVIDENCE / f'{label}-manifest.json')
    shutil.copyfile(asset, EVIDENCE / f'{label}-build-manifest.json')
    print(f'{label}: {len(files)} inputs; {len(payload["changed_from_before"])} changed from review baseline')


if __name__ == '__main__':
    cli = argparse.ArgumentParser()
    cli.add_argument('label')
    freeze(cli.parse_args().label)
