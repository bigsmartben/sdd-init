"""Evaluation harness for this review batch. Only sandboxed fixture copies are model workspaces."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import argparse
import hashlib
import importlib.util
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import tomllib
from contextlib import ExitStack
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread

BATCH = Path(__file__).resolve().parent
WORKSPACE = BATCH.parents[1]
VENDOR = WORKSPACE / ".build/prompt-role-workflow-review/client/node_modules/@openai/codex-linux-x64/vendor/x86_64-unknown-linux-musl"
AUTH = Path("/mnt/c/Users/24598/.codex/auth.json")
EVIDENCE = WORKSPACE / "docs/test-reports/sdd-workflow/evidence/2026-11-15-workflow-fixes"
SINGLE_PREFIX = "Task from Main."
BROWSER = Path("/home/ben/.cache/sdd-role-isolation/browser.6dsY9CHQ")
NODE = Path("/home/ben/.nvm/versions/node/v24.16.0/bin/node")
ZONE = ZoneInfo("Asia/Shanghai")
DEFAULT_MODEL = "gpt-6.1-sol"
EFFORT = "medium"
OPS = {"release-final-evidence", "release-stale-evidence", "release-missing-evidence",
       "rollback-partial", "release-confirmed", "release-query-only", "rollback-confirmed", "role_devops_backup_gate"}
SPECIAL = {
    "architecture_design": "role_architect",
    "role_doc_runtime_boundary": "role_doc_consistency",
    "develop_exception_decision": "develop_spec_only",
    "develop_direct_role_work_order": "role_coder",
    "refactor_then_integration": "refactor_behavior_boundary",
    "formal_ui_acceptance": "role_product_manager",
}
PROFILE_CASES = {"review_prompt_read_only", "review_prompt_compare", "review_prompt_revise"}
GATE = {"workflow_review_explicit", "workflow_review_not_requested"}
STACKED_OVERRIDE = (
    "\n本轮测试环境是当前隔离项目中的本地 Python 及文件 SQLite。目标依次为当前和修复后实际快照。"
    "已确认项目范围包括新建、取消、提交、公开付款及 AC-3，主要用户路径依现有 Spec 和公开入口。"
    "上述阶段、范围、版本选择、环境和现有行为判据均已确认。外部端点和权限暂缺。"
    "测试可写指南、报告与 Issue。本地修复限于受证据支持的现行缺陷；适用架构规则与整改边界依工作请求。"
)
ROLE_SETUP = "Use the sole registered custom role named {role} to execute this work order and return its actual receipt. Keep all work in this isolated project.\n\n"
FIXTURE_BOUNDARY = "仅在当前隔离项目操作。本地文件及 Git 操作须与工单一致。使用给定共享规则。不得接触原仓、已安装工作流、外部平台或真实部署。\n\n"


def now():
    return datetime.now(ZONE).isoformat(timespec="seconds")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bind_candidate(label):
    global REPO, RELEASE, CHECKER, prepare, CASES, BASELINE, SNAPSHOT_LABEL
    assert label.isascii() and label.replace("-", "").isalnum(), label
    SNAPSHOT_LABEL = label
    REPO = BATCH / "snapshots" / label
    RELEASE = REPO / "release"
    CHECKER = REPO / "tests/fixtures/skill-behavior/run_prototype_check.cjs"
    BASELINE = json.loads((REPO / "manifest.json").read_text(encoding="utf-8"))
    assert BASELINE["label"] == label
    for name, expected in BASELINE["files"].items():
        assert sha(REPO / name) == expected, name
    for name, expected in BASELINE["simulator"].items():
        assert sha(REPO / "simulator" / name) == expected, name
    release_manifest = RELEASE / "build-manifest.json"
    assert sha(release_manifest) == BASELINE["release_manifest_sha256"]
    for name, expected in json.loads(release_manifest.read_text(encoding="utf-8"))["files"].items():
        assert sha(RELEASE / name) == expected, name
    preparer = importlib.util.spec_from_file_location("prepare_cases", REPO / "tests/prepare_skill_behavior.py")
    prepare = importlib.util.module_from_spec(preparer)
    preparer.loader.exec_module(prepare)
    CASES = prepare.load_cases()


def json_to(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def clean_env(path):
    runtime = "/usr/bin:/bin"
    return {"PATH": f"{path / 'tools'}:{NODE.parent}:{runtime}", "LANG": "C.UTF-8",
            "TZ": "Asia/Shanghai", "PYTHONDONTWRITEBYTECODE": "1",
            "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_CONFIG_SYSTEM": "/dev/null",
            "RUST_LOG": "warn"}


def git(project, env, *args):
    return subprocess.run(["git", *args], cwd=project, env=env, text=True, encoding="utf-8",
                          check=True, capture_output=True).stdout.strip()


def snapshot(root):
    return {p.relative_to(root).as_posix(): sha(p) for p in sorted(root.rglob("*"))
            if p.is_file() and not p.is_symlink()
            and not {".git", "__pycache__"}.intersection(p.relative_to(root).parts)}


def put_file(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def permissions(name, program, scratch, shared=None, mutable=False, git_write=False, report_only=False):
    file_rules = [f'"{program}" = "read"']
    if shared is not None:
        file_rules.append(f'"{shared}" = "read"')
    if mutable:
        file_rules.append(f'"{scratch}" = "write"')
    scope_rules = [f'"." = "{"write" if mutable and not report_only else "read"}"']
    if report_only:
        scope_rules.append('"docs/test-reports/sdd-workflow" = "write"')
    if mutable:
        scope_rules.extend(['".agents" = "read"', '".codex" = "read"'])
        scope_rules.append(f'".git" = "{"write" if git_write else "read"}"')
    return (f'[permissions.{name}.filesystem]\n":minimal" = "read"\n'
            + "\n".join(file_rules) + "\n"
            + f'[permissions.{name}.filesystem.":workspace_roots"]\n'
            + "\n".join(scope_rules) + "\n"
            + f'[permissions.{name}.network]\nenabled = false\n')


def read_sessions(config, evidence):
    result = []
    per_session = evidence / "sessions"
    per_session.mkdir(exist_ok=True)
    for fp in sorted((config / "sessions").rglob("*.jsonl")):
        identity = {}
        identities = []
        applied_role_sha = None
        role_probe = None
        final_usage = None
        model = None
        trace = []
        for line in fp.read_text(encoding="utf-8").splitlines():
            try:
                event = json.loads(line)
            except ValueError:
                continue
            body = event.get("payload", {})
            event_type = event.get("type")
            response_type = body.get("type", "")
            if event_type == "session_meta":
                identity = {k: body[k] for k in ("id", "source", "agent_role", "agent_nickname",
                                                  "cli_version", "model_provider") if k in body}
                identities.append(identity)
                if body.get("agent_role"):
                    role_probe = body["agent_role"]
                trace.append({"timestamp": event.get("timestamp"), "identity": identity})
            elif event_type == "turn_context":
                model = body.get("model", model)
                trace.append({"timestamp": event.get("timestamp"),
                              "turn_context": {k: body.get(k) for k in ("turn_id","model","effort","approval_policy","sandbox_policy","permission_profile") if k in body}})
            elif event_type == "event_msg" and response_type == "token_count":
                totals = (body.get("info") or {}).get("total_token_usage")
                if totals:
                    final_usage = totals
            elif event_type == "response_item" and response_type in {
                    "function_call", "function_call_output", "custom_tool_call", "custom_tool_call_output"}:
                # Model and fixture tool actions only. Exclude system/instruction and credential data.
                keep = {k: body[k] for k in ("type", "call_id", "name", "arguments", "input", "output") if k in body}
                trace.append({"timestamp": event.get("timestamp"), **keep})
            elif event_type == "response_item" and response_type == "message" and body.get("role") == "developer" and role_probe:
                if role_probe == "review-prompt":
                    role_path = prepare.REVIEW_ROLE
                else:
                    role_path = REPO/"source/project/.codex/agents"/f"{role_probe}.toml"
                if role_path.is_file():
                    role_text = tomllib.loads(role_path.read_text(encoding="utf-8"))["developer_instructions"]
                    if any(role_text.strip() in item.get("text","") for item in body.get("content",[])):
                        applied_role_sha = sha(role_path)
            elif event_type == "response_item" and response_type == "message" and body.get("role") == "assistant":
                trace.append({"timestamp": event.get("timestamp"), "assistant": body.get("content")})
        output = per_session / fp.name
        output.write_text("".join(json.dumps(entry, ensure_ascii=False) + "\n" for entry in trace), encoding="utf-8")
        result.append({"identity": identities[0] if identities else identity, "identities":identities,
                       "observed_role_instructions_sha":applied_role_sha,"model": model,"usage":final_usage,
                       "records": len(trace), "trace": output.relative_to(evidence).as_posix()})
    return result


def copy_changes(project, output, before, after):
    changes = [name for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)]
    for name in changes:
        source = project / name
        if source.is_file() and not source.is_symlink():
            destination = output / "changed" / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
    return changes


def prepare_project(name, work, env, evidence):
    if name in OPS:
        # Provision with the repository's pre-existing file-backed production-sim fixture.
        old_path = REPO/"simulator/behavior.py"
        setup = OPS_FIXTURE
        project = work/"project"
        (project/"ops").mkdir(parents=True)
        # Fixture generator takes one optional resource directory. Use the current
        # release, no previously installed resource or execution harness is run.
        resources = project/".agents/skills/sdd-workflow"
        input_case = {"release-confirmed":"release-final-evidence", "release-query-only":"release-final-evidence",
                      "rollback-confirmed":"rollback-partial", "role_devops_backup_gate":"release-stale-evidence"}.get(name,name)
        setup.set_inputs(input_case,project,resources)
        if name != "role_devops_backup_gate":
            with (project/"docs/runbooks/orders.md").open("a",encoding="utf-8") as runbook:
                runbook.write("\n`ops/state.json` is the simulator's active state, updated in place by its operations. "
                              "It holds the online artifact catalog and current runtime, and is distinct from the static qualification "
                              "records under `docs/evidence/`. Live observations and incident data are also obtained through the simulator.\n")
        if name == "role_devops_backup_gate":
            state_path = project/"ops/state.json"
            state = json.loads(state_path.read_text(encoding="utf-8"))
            state["legacy"] = {"service":"orders-legacy","running":True,"route":"orders-legacy",
                "legacy_percent":100,"job":"running","approved_retention":"keep-source"}
            json_to(state_path,state)
            json_to(project/"ops/legacy.json",[{"id":n,"type":"legacy-order"} for n in (5,6,7)])
            role = "sdd-devops"
            role_path = project/".codex/agents/sdd-devops.toml"
            role_path.parent.mkdir(parents=True)
            shutil.copyfile(RELEASE/"shared/agents/sdd-devops.toml",role_path)
            put_file(project/".codex/config.toml",'[agents]\nmax_threads=1\nmax_depth=1\n[agents.sdd-devops]\nconfig_file="agents/sdd-devops.toml"\n')
            shutil.rmtree(resources/"skills")
            git(project,env,"init","-q","--template=","-b","main")
            request = ("Task from Main. This is a file-backed test lab. Review readiness for release 2.4.0 to production-sim. "
                       "The planned release is awaiting my explicit confirmation and may have evidence gaps. "
                       "Release readiness is limited to reading the existing records; do not call the release simulator endpoints "
                       "and do not deploy, smoke, or route. Separately, the independent local backup of orders-legacy is approved "
                       "for this exercise, including local reads and calls to backup and backup-verify. Perform that backup now, "
                       "verify the data, and return both results, impact and actual recovery conditions. Do not restore or retire. "
                       "Read docs/runbooks/orders.md and its indexed records. Keep work in this fixture. "
                       "Write the receipt to docs/delivery/backup-and-release.md.")
            put_file(project/"TASK.txt",request)
            git(project,env,"add","--all")
            git(project,env,"-c","user.name=SDD fixture","-c","user.email=fixture@example.invalid","commit","-qm","Backup and release-control fixture")
            json_to(evidence/"candidate-manifest.json",{
                "fixture_generator_sha256":sha(old_path),
                "fixture_simulator_sha256":sha(project/"ops/sim.py"),
                "current_release_manifest_sha256":sha(RELEASE/"build-manifest.json"),
                "role_sha256":sha(role_path),
                "initial_fixture_files":snapshot(project),
            })
            return {"role":role},project,None
        shutil.rmtree(project/".agents")
        role_resources = work/"workflow-bundle"
        shutil.copytree(RELEASE,role_resources)
        git(project,env,"init","-q","--template=","-b","main")
        completed = subprocess.run([sys.executable,"-B",str(role_resources/"scripts/govern.py"),
                                    "--root",str(project),"init"],env=env,cwd=project,
                                    capture_output=True,text=True,encoding="utf-8")
        put_file(evidence/"init.txt",completed.stdout+completed.stderr)
        completed.check_returncode()
        assert not git(project,env,"remote")
        git(project,env,"add","--all")
        git(project,env,"-c","user.name=SDD fixture","-c","user.email=fixture@example.invalid",
            "commit","-qm","Isolated file-backed simulator")
        request = setup.incident_request if input_case == "rollback-partial" else setup.release_request
        put_file(project/"TASK.txt",request)
        json_to(evidence/"candidate-manifest.json",{
            "fixture_generator_sha256":sha(old_path),
            "fixture_simulator_sha256":sha(project/"ops/sim.py"),
            "current_release_manifest_sha256":sha(RELEASE/"build-manifest.json"),
            "initial_fixture_files":snapshot(project),
        })
        return {},project,role_resources/"shared"
    case = CASES[SPECIAL.get(name, name)].copy()
    if name in {"architecture_design","develop_direct_role_work_order","formal_ui_acceptance"}:
        case.pop("role")
    if name == "formal_ui_acceptance":
        case = formal_ui_case(case)
    is_role = case.get("role") is not None or name in PROFILE_CASES
    is_workflow_trigger = name.startswith("workflow_review_")
    project = prepare.prepare_case(case, work/"prepared")
    for filename in ("candidate-manifest.json", "evaluation.json"):
        shutil.copyfile(project.parent / filename, evidence / filename)
    manifest = json.loads((project.parent / "candidate-manifest.json").read_text(encoding="utf-8"))
    baseline = BASELINE
    for name_in_project, expected in manifest["files"].items():
        candidate_path = name_in_project
        if case.get("role"):
            candidate_path = candidate_path.replace(".agents/skills/sdd-workflow/sdd/", ".agents/sdd/", 1)
        if not is_workflow_trigger:
            candidate_path = "source/project/" + candidate_path
        if baseline["files"].get(candidate_path) != expected:
            raise ValueError(f"Candidate differs from original snapshot: {candidate_path}")
    if name in PROFILE_CASES:
        expected = baseline["files"]["source/initializer/assets/user-agents/review-prompt.toml"]
        assert manifest["profile_files"][".codex/agents/review-prompt.toml"] == expected
    git(project,env,"init","-q","--template=","-b","main")
    if not is_role and not is_workflow_trigger:
        # Actual layout established by the current initializer, using this temporary candidate only.
        # The preparer already preserved the raw candidate hashes above.
        shutil.rmtree(project / ".agents")
        shutil.rmtree(project / ".codex")
        (project / "AGENTS.md").unlink()
        linked_release = work / "workflow-bundle"
        shutil.copytree(RELEASE, linked_release)
        completed = subprocess.run([sys.executable,"-B",str(linked_release/"scripts/govern.py"),
                                    "--root",str(project),"init"],env=env,cwd=project,
                                   capture_output=True,text=True,encoding="utf-8")
        (evidence/"init.txt").write_text(completed.stdout+completed.stderr,encoding="utf-8")
        completed.check_returncode()
        shared = linked_release / "shared"
    else:
        shared = None
    if name == "workflow_review_explicit":
        p = project / ".codex/agents/review-prompt.toml"
        p.parent.mkdir(parents=True)
        shutil.copyfile(prepare.REVIEW_ROLE, p)
        assert sha(p) == baseline["files"]["source/initializer/assets/user-agents/review-prompt.toml"]
        put_file(project / ".codex/config.toml", '[agents.review-prompt]\nconfig_file = "agents/review-prompt.toml"\n')
        json_to(evidence / "explicit-review-role.json", {"path": p.relative_to(project).as_posix(), "sha256": sha(p)})
    if name == "role_doc_runtime_boundary":
        put_file(project/"src/retry_prompt.txt","Runtime model instructions: do not treat as project policy.\n")
        i = project/"docs/index.md"
        put_file(i,i.read_text()+"\n- [Embedded runtime prompt](../src/retry_prompt.txt)\n")
    git(project,env,"add","--all")
    git(project,env,"-c","user.name=SDD fixture","-c","user.email=fixture@example.invalid",
        "commit","-qm","Isolated fixture baseline")
    if name == "integration_resume_after_fix":
        first_commit = git(project,env,"rev-parse","HEAD")
        runs = {}
        first_dir = project/"docs/test-reports/order/evidence"
        first_dir.mkdir(parents=True,exist_ok=True)
        for ac in ("AC-1","AC-2"):
            check = subprocess.run([sys.executable,"-B","checks/acceptance.py","--scenario",ac],
                                   env=env,cwd=project,capture_output=True,text=True,encoding="utf-8")
            runs[ac] = {"exit":check.returncode,"stdout":check.stdout,"stderr":check.stderr}
            assert check.returncode == (0 if ac=="AC-1" else 1)
        json_to(first_dir/"b1.json",runs)
        put_file(first_dir.parent/"b1.md", f"# B1 order integration\n\nBaseline commit {first_commit}. "
                 "Local Python and file SQLite. AC-1 PASS, AC-2 FAIL, AC-3 blocked on endpoint and permission. "
                 "The failure is ISS-001. [Raw checks](evidence/b1.json).\n")
        path = project/"src/order_service.py"
        old = path.read_text(encoding="utf-8")
        previous = 'def submit_order(connection, order_id):\n    read_status(connection, order_id)\n'
        assert previous in old
        put_file(path,old.replace(previous,'def submit_order(connection, order_id):\n    if read_status(connection, order_id) == "cancelled":\n        return False\n',1))
        put_file(project/"docs/issues/ISS-001.md",
                 "# ISS-001 — Cancelled order can be submitted\n\n"
                 "Status: Fixed, awaiting verification. On B1, AC-2 returned true and persisted submitted. "
                 "The original criteria are AC-2 false with cancelled still persisted after a reopen, "
                 "and AC-1 true with submitted as the necessary regression. "
                 "The scope is integration evidence only, no Issue closure authorization. "
                 "[B1](../test-reports/order/b1.md).\n")
        git(project,env,"add","--all")
        git(project,env,"-c","user.name=SDD fixture","-c","user.email=fixture@example.invalid",
            "commit","-qm","Fixture handoff: restore cancelled-order rule")
        json_to(evidence/"handoff-b1.json",{"prior":first_commit,
            "current":git(project,env,"rev-parse","HEAD"),"runs":runs})
    if name == "role_devops":
        p = project / "ops/rollout.txt"
        assert "candidate-a" in p.read_text()
        put_file(p,p.read_text().replace("candidate-a","candidate-b"))
        p = project / "notes.txt"
        put_file(p,p.read_text()+"\nindependent staged note\n")
        git(project,env,"add","notes.txt")
    if name == "deliver_commit_then_choose":
        p = project / "src/order.py"
        put_file(p,p.read_text()+"\n# authorized fixture change\n")
        git(project,env,"config","--local","user.name","SDD fixture")
        git(project,env,"config","--local","user.email","fixture@example.invalid")
        git(project,env,"switch","-c","fix/order")
        mock_remote = "https://git.example.invalid/team/shop.git"
        git(project,env,"remote","add","origin",mock_remote)
        config_path = project / "evidence/repository.json"
        fixture_repository = json.loads(config_path.read_text(encoding="utf-8"))
        fixture_repository["remote"] = mock_remote
        json_to(config_path,fixture_repository)
        git(project,env,"add","--","evidence/repository.json")
        git(project,env,"-c","user.name=SDD fixture","-c","user.email=fixture@example.invalid", "commit","-qm","Use a non-routable fixture remote")
    return case, project, shared


def formal_ui_case(case):
    prototype_path = "tests/prototypes/checklist/personal/index.html"
    prototype_run = EVIDENCE/"final-isolated/role_product_manager"
    prototype = (prototype_run/"changed"/prototype_path).read_bytes()
    original = json.loads((prototype_run/"run.json").read_text(encoding="utf-8"))
    assert hashlib.sha256(prototype).hexdigest() == original["after"][prototype_path]
    product = '''<!doctype html><meta charset="utf-8"><title>Checklist application</title>
<h1>Checklist</h1><form><label>Item <input name="item" type="text"></label><button>Add</button></form>
<div role="alert" hidden></div><ul></ul>
<script>
const form = document.querySelector('form'), alertBox = document.querySelector('[role="alert"]');
const list = document.querySelector('ul');
const items = JSON.parse(localStorage.getItem('checklist') || '[]');
const persist = () => localStorage.setItem('checklist', JSON.stringify(items));
function addRow(item) {
  const row = document.createElement('li'), label = document.createElement('label'), box = document.createElement('input');
  box.type = 'checkbox'; box.checked = item.checked;
  box.onchange = () => { item.checked = box.checked; persist(); };
  label.append(box, document.createTextNode(item.name)); row.append(label); list.append(row);
}
items.forEach(addRow);
form.addEventListener('submit', event => {
  event.preventDefault(); const raw = form.elements.namedItem('item').value;
  if (!raw.trim()) { alertBox.textContent = 'An item is required'; alertBox.hidden = false; return; }
  alertBox.hidden = true;
  const item = {name: raw, checked: false}; items.push(item); persist(); addRow(item); form.reset();
});
</script>'''
    case["id"] = "formal_ui_acceptance"
    case["input"] = ("用 $sdd-test-loop 对当前隔离清单候选进行范围内全功能集成验收。唯一 Web 客户端及初始版本是本项目当前 HEAD。"
                      "目标为本地 HTTP 正式页面，主要用户路径、范围、判据及环境均已确认，见 docs/index.md。"
                      "可从当前会话使用本地浏览器工具。只能写 Quickstart、验收报告及必要 Issue；产品、原型和测试工具只读。交付实际版本、逐项结果和 Test Gate。")
    case["files"] = {
        "README.md": "# Checklist application fixture\n\nRead [the project index](docs/index.md).\n",
        "docs/index.md": "# Project index\n\n- [Current checklist Spec and fixed prototype](../specs/checklist/spec.md)\n"
                         "- [Local browser entries](browser.md)\n",
        "docs/browser.md": "# Local browser entries\n\nThe fixture publishes its isolated formal implementation at `/src/index.html`. "
                           "The local `local_browser_fixture` MCP server has `run_prototype_check` for the approved prototype and "
                           "`run_formal_check` for the formal HTTP entry. Each returns the actual browser, case evidence and tested HTML digest. "
                           "The two entries are served from the same loopback-only fixture host. They have separate browser state.\n",
        "specs/checklist/spec.md": "# Checklist Spec\n\nVersion scope: this repository’s current candidate in its isolated browser environment. "
                                  "The approved simulated prototype uses browser memory. The formal page uses local browser storage. Only behavior below is in acceptance.\n\n"
                                  "| ID | Confirmed behavior |\n| --- | --- |\n"
                                  "| AC-1 | Blank or spaces-only input shows an inline alert and does not create an item. |\n"
                                  "| AC-2 | Submitting `  Pack bag  ` displays and stores the item as `Pack bag` without surrounding spaces. |\n"
                                  "| AC-3 | Adding two items yields two unchecked boxes; checking one does not change the other. |\n"
                                  "| AC-4 | Unchecking one keeps the other’s state; both can be unchecked. |\n\n"
                                  f"[Approved prototype](../../{prototype_path}), SHA-256 `{original['after'][prototype_path]}`. "
                                  "The prototype is the confirmed reference for the four user interactions, and a separate actual candidate witness is required.\n",
        "src/index.html": product,
        prototype_path: prototype.decode("utf-8"),
    }
    case["expected"] = ["Execute frozen prototype and formal page in Chromium using the two distinct actual URLs and SHA-256 values",
                        "Formal AC-2 fails via visible label/storage discrepancy, AC-1/3/4 pass; Test Gate FAIL",
                        "Retain original prototype, source and success criteria; issue only, no architecture phase required"]
    case["forbidden"] = ["Count prototype as verification of the formal candidate", "Repair in a test-only task", "Report Test Gate PASS"]
    return case


def make_prompt(name,case,project):
    task = (project/"TASK.txt").read_text(encoding="utf-8")
    if name == "release-query-only":
        return (task + "\n测试用户本次明确确认：可在 production-sim 用既有入口核对 2.4.0 制品、当前订单运行状态和基线观测。"
                "我暂未确认生产式部署、冒烟、切流和变更。请先完成上述查询，回报实际状态和后续评估，等确认后再执行变更。")
    if name in {"release-confirmed","rollback-confirmed"}:
        if name == "release-confirmed":
            affirmation = ("\n测试用户回传：已确认本地替身上对 2.4.0 的生产式查询、现有 canary 部署、冒烟、"
                           "/checkout 10% 切流和数据面观察。已阅读评估：起初 canary 无流量，schema 7 和数据不变，"
                           "流量切换后 10% 暴露于候选风险，若状态不明应先读回，直接回切至 0% 不在现有入口。"
                           "确认上述本地模拟操作和影响，继续。")
        else:
            affirmation = ("\n测试用户回传：已确认在本地替身查询并将运行程序回滚至 2.3.9，接受短时 checkout 影响。"
                           "了解 schema 7 保持，数据检查只读，已确认不恢复或覆盖数据。允许本地健康、冒烟和依赖核对。")
        return task + affirmation + "\n严格限当前本地替身；本回传是夹具输入，禁止真实外部访问。"
    if name in OPS and not case.get("role"):
        return task + ("\n已确认 production-sim 的模拟验证范围。本任务不影响任何真实平台、网络、用户安装或仓库。"
                       "需要用户确认的生产前置保持真实的停止边界；初始请求只授权范围与目标。"
                       "在已可读的本地夹具内，完成权限允许且不依赖该确认的取证，明确待确认时点和影响。")
    if case.get("role"):
        return ROLE_SETUP.format(role=case["role"]) + task
    if name == "develop_direct_role_work_order":
        return FIXTURE_BOUNDARY + ("主任务，请直接把 docs/order-id-work.md 的已签发实施工单交给已注册的 sdd-coder。"
                   "已经确认需求和实施范围。授权终点是实施、同一 Plan／Task 和工单约定的局部自验。"
                   "验收和全产品集成由 Main 之后另行安排。本轮要求你以实际调用者身份回收角色回执，"
                   "并核对工单、局部证据和待验；这个仓库有全套阶段 Skill，但目前只交付这份专业产物。")
    if name == "develop_exception_decision":
        return FIXTURE_BOUNDARY + ("请用 $sdd-develop 处理一个候选需求，只讨论是否要改变订单超时后的用户结果。"
                   "现行业务已确认提交在外部回执无法核对时保留已有订单结果。业务同事建议对超时自动取消，"
                   "但产品负责人还没有确认这项新行为。新建、取消、提交、付款主流程不变。"
                   "请核对当前规格、给我看影响与选项。")
    if name == "integration_resume_after_fix":
        return FIXTURE_BOUNDARY + task + ("\n当前已确认版本就是 HEAD，主要路径按规格，环境为本地 Python／文件 SQLite。"
                   "B1 报告位于 docs/test-reports/order/b1.md，原 Issue 位于 docs/issues/ISS-001.md。"
                   "外部端点、权限暂缺。只写本轮测试证据与报告，不改变原 Issue 的状态。")
    if name in PROFILE_CASES:
        # Role should receive exactly the work brief, then report to its actual caller.
        return ROLE_SETUP.format(role="review-prompt") + task
    if name in {"collaboration_workflow", "collaboration_blind_workflow"}:
        if name == "collaboration_blind_workflow":
            return FIXTURE_BOUNDARY + task + ("\n范围、公开路径和判据沿用订单 Spec，环境为本地 Python 和文件 SQLite。"
                    "集成用修复后实际候选，外部端点及权限缺失。架构检查仅取证，产品改动限于本次明确缺陷。"
                    "可写本地指南、报告和 Issue。无 Git 或外部交付授权。")
        return FIXTURE_BOUNDARY + task + STACKED_OVERRIDE
    if name == "architecture_design":
        return FIXTURE_BOUNDARY + ("请使用 $sdd-architecture。已确认要进行架构蓝图演化，决定见 docs/decision.md；"
                "将其原位归并到现有 Blueprint 和关联 Scenario Sequence，沿用现有公开契约，"
                "本次只授权设计文档及相称验证。暂不实施。")
    if name == "refactor_then_integration":
        return FIXTURE_BOUNDARY + task + (
            "\n以上是第一阶段。随后继续对复核后的实际隔离候选做全产品集成；两个阶段均已授权。"
            "范围是新建、取消、提交、公开付款及 AC-3，现有公开判据、路径和本地 Python／文件 SQLite 环境均已确认。"
            "外部回执没有端点或授权，按待验处理。可写指南、集成报告和 Issue；只允许前述付款路径改动。")
    if name == "workflow_review_explicit":
        return task + ("在全面评审中，请实际调用夹具注册的 review-prompt，只读核对 guidance/main.md、"
                       "guidance/prompt.md 的提示词和适用判据。工单使用夹具白皮书与 Spec，传入证据边界。"
                       "回收其实际回执，在批次报告关联对象、判据、证据位置及未验范围。"
                       "本 Skill 自行归并综合结论。报告和必要证据仅写 docs/test-reports/sdd-workflow/。")
    if name == "workflow_review_not_requested":
        return task
    return FIXTURE_BOUNDARY + task


def run_cli(command, env, project, evidence, input_text, timeout):
    stamp = now()
    started = time.monotonic()
    with (evidence / "events.jsonl").open("w",encoding="utf-8") as events, (
          evidence / "client.log").open("w",encoding="utf-8") as stderr:
        process = subprocess.Popen(command,env=env,cwd=project,stdin=subprocess.PIPE,
                                   stdout=events,stderr=stderr,text=True,encoding="utf-8",start_new_session=True)
        try:
            process.communicate(input_text,timeout=timeout)
            result = process.returncode
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGTERM)
            process.wait(timeout=20)
            result = 124
    return {"start": stamp, "end": now(), "seconds": round(time.monotonic()-started,3),
            "exit": result}


def run(name, batch, program):
    output = batch / name
    output.mkdir()
    with tempfile.TemporaryDirectory(prefix=f"{name}-",dir=program.parent) as raw, ExitStack() as cleanup:
        work = Path(raw)
        env = clean_env(program)
        client = program/"bin/codex"
        user_profile = work/"isolated-user"
        user_profile.mkdir(mode=0o700)
        config = user_profile/".codex"
        config.mkdir(mode=0o700)
        scratch = work/"scratch"
        scratch.mkdir()
        # Scope configuration and skill discovery to the child process and its disposable home.
        env.update({"HOME":str(user_profile), "CODEX_HOME":str(config), "TMPDIR":str(scratch)})
        case,project,shared = prepare_project(name,work,env,output)
        prompt = make_prompt(name,case,project)
        put_file(output/"request.txt",prompt)
        read_only = name in {"role_doc_consistency","role_doc_runtime_boundary","review_prompt_read_only","review_prompt_compare"}
        permission = "fixture-read" if read_only else "fixture-write"
        config_text = (f'model = "{DEFAULT_MODEL}"\nmodel_reasoning_effort = "{EFFORT}"\n'
                       f'default_permissions = "{permission}"\napproval_policy = "never"\n'
                       'cli_auth_credentials_store = "file"\nsuppress_unstable_features_warning = true\nallow_login_shell = false\n'
                       '[features]\nplugins = false\nmulti_agent_v2 = true\n'
                       'skill_search = false\nskip_host_skill_discovery = true\n'
                       '[agents]\nmax_threads = 8\nmax_depth = 2\n\n'
                       + permissions(permission,program,scratch,shared,not read_only,
                                     name in {"role_devops","deliver_commit_then_choose"},
                                     report_only=name == "workflow_review_explicit"))
        if name in PROFILE_CASES:
            files = project.parent/"profile/.codex/agents"
            shutil.copytree(files,config/"agents")
        if name in {"role_product_manager", "formal_ui_acceptance"}:
            runner = work/"run_prototype_check.cjs"
            if name == "formal_ui_acceptance":
                shutil.copyfile(BATCH/"formal_ui_browser.cjs",runner)
                class FixturePages(SimpleHTTPRequestHandler):
                    def do_GET(self):
                        if self.path not in {"/src/index.html", "/tests/prototypes/checklist/personal/index.html"}:
                            self.send_error(404)
                            return
                        super().do_GET()

                server = ThreadingHTTPServer(("127.0.0.1",0),partial(FixturePages,directory=str(project)))
                cleanup.callback(server.server_close)
                Thread(target=server.serve_forever,daemon=True).start()
                cleanup.callback(server.shutdown)
                browser_args = f'["{runner}", "http://127.0.0.1:{server.server_port}"]'
                approval = "[mcp_servers.local_browser_fixture.tools.run_formal_check]\napproval_mode = \"approve\"\n"
            else:
                shutil.copyfile(CHECKER,runner)
                browser_args = f'["{runner}", "{project}", "--mcp"]'
                approval = ""
            config_text += (
                "[mcp_servers.local_browser_fixture]\n"
                f'command = "{NODE}"\n'
                f'args = {browser_args}\n'
                "[mcp_servers.local_browser_fixture.env]\n"
                f'NODE_PATH = "{BROWSER/"node_modules"}"\nPLAYWRIGHT_BROWSERS_PATH = "{BROWSER/"browsers"}"\n'
                "[mcp_servers.local_browser_fixture.tools.run_prototype_check]\napproval_mode = \"approve\"\n" + approval
            )
        put_file(config/"config.toml",config_text)
        put_file(output/"profile.toml",config_text)
        if name == "workflow_review_explicit":
            guard = "/bin/sh", "-ec", ("cat guidance/main.md >/dev/null; "
                        "touch docs/test-reports/sdd-workflow/.permission-probe; "
                        "rm docs/test-reports/sdd-workflow/.permission-probe; "
                        "test ! -e .should-not-exist; "
                        "if touch .should-not-exist 2>/dev/null; then exit 17; fi; "
                        "if cat ../evaluation.json >/dev/null 2>&1; then exit 18; fi; "
                        "printf 'fixture-read=ALLOWED\\nreport-write=ALLOWED\\nworkspace-other-write=DENIED\\nevaluation-read=DENIED\\n'")
            check = subprocess.run([str(client),"sandbox","--include-managed-config","-P",permission,
                                    "-C",str(project),"--",*guard],cwd=project,env=env,
                                   capture_output=True,text=True,encoding="utf-8")
            put_file(output/"permission-check.txt",check.stdout+check.stderr+f"exit={check.returncode}\n")
            check.check_returncode()
        before = snapshot(project)
        base_commit = git(project,env,"rev-parse","HEAD")
        git_before = git(project,env,"status","--short")
        auth = config/"auth.json"
        fd = os.open(auth,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,"wb") as out, AUTH.open("rb") as inp:
            shutil.copyfileobj(inp,out)
        try:
            cli_command = [str(client),"-a","never","exec"]
            followups = {
                "develop_delivery": [
                    ("B", "确认 A。已确认空或全空白订单号按空字符串处理：拒绝且不创建订单。合法订单号照常创建，其他订单行为保持。请先仅固化规格与方案，等待我确认后再交付实施。"),
                    ("delivery", "确认 B。按刚才的范围、用户流程和已确认的就绪条件开始实施，并完成本轮隔离验收。"),
                ],
                "collaboration_workflow": [
                    ("unchanged-evidence", "基于刚完成的同一记录，只归并这次补充的运行条件事实：运行仍为同一隔离项目、本地文件 SQLite，AC-3 端点和权限没有变化。实现、接口、环境和数据均未改变，不执行新测试。请在本轮的现有报告关联该事实，说明还能复用哪些证据。"),
                ],
                "develop_user_acceptance_feedback": [
                    ("status-query", "现在 WO-ORDER-018 的本地验收到哪一步？请按已有记录说明通过、待验和下一步。本轮无运行条件或候选变化，我还未提供观察结果。"),
                    ("user-feedback", "我是本轮夹具的验收用户。我刚在同一候选的本地终端实际执行了收据入口。终端显示 {observation}。我可以独立辨认订单当前为已提交、下一步是等待履约，AC-UX 的观察符合工单要求。请归并这次实际反馈。"),
                ],
                "refactor_user_acceptance_feedback": [
                    ("user-feedback", "我是本轮夹具的验收用户。我刚在同一候选的本地终端实际执行了付款收据入口。终端显示 {observation}。我能独立辨认已付款状态和保留收据的下一步，BP-019 的观察符合工单要求。请按原检查项归并这次实际反馈。"),
                ],
            }
            result = run_cli([*cli_command,"--trust","--json","-o",str(output/"receipt.md"),"-"],
                             env,project,output,prompt,
                             timeout=780 if name in {"collaboration_workflow","collaboration_blind_workflow","refactor_then_integration"} else 450)
            if name in followups and result["exit"] == 0:
                stages = [{"turn":"initial", "metrics":result.copy(), "files":snapshot(project)}]
                root_id = next(json.loads(line)["thread_id"] for line in
                               (output/"events.jsonl").read_text(encoding="utf-8").splitlines()
                               if line.startswith('{"type":"thread.started"'))
                for turn,feedback in followups[name]:
                    phase = output / turn
                    phase.mkdir()
                    if "{observation}" in feedback:
                        observed = subprocess.run([sys.executable,"-B","checks/receipt_preview.py"], cwd=project,
                                                  env=env, capture_output=True,text=True,encoding="utf-8",check=True)
                        put_file(phase/"operator-observation.txt", observed.stdout)
                        feedback = feedback.replace("{observation}", observed.stdout.strip())
                    put_file(phase/"request.txt",feedback+"\n")
                    latest_receipt = (output/"receipt.md").read_text(encoding="utf-8")
                    if name == "develop_delivery":
                        prior = stages[-1]["files"]
                        touched = {n for n in before.keys()|prior.keys() if before.get(n)!=prior.get(n)}
                        blocked = any(n.startswith(("src/","tests/","checks/")) for n in touched)
                        if turn=="B": blocked |= any(n.startswith("specs/") for n in touched)
                        else: blocked |= not any(n.startswith("specs/") for n in touched)
                        if blocked or "确认" not in latest_receipt:
                            put_file(phase/"not-run.txt","Previous turn did not reach the required confirmation checkpoint.\n")
                            break
                    resumed = run_cli([*cli_command,"resume","--json","-o",str(phase/"receipt.md"),root_id,"-"],
                                      env,project,phase,feedback,timeout=300)
                    stages.append({"turn":turn,"metrics":resumed,"files":snapshot(project)})
                    if resumed["exit"] != 0:
                        break
                    shutil.copyfile(phase/"receipt.md",output/"receipt.md")
                result["turns"] = stages
                result["end"] = stages[-1]["metrics"]["end"]
            sessions = read_sessions(config,output)
        finally:
            auth.unlink(missing_ok=True)
        after = snapshot(project)
        result.update(case=name,permission_profile=permission,model=DEFAULT_MODEL,effort=EFFORT,
                      before=before,after=after,changed=copy_changes(project,output,before,after),
                      base_commit=base_commit, head_after=git(project,env,"rev-parse","HEAD"),
                      commit_paths=git(project,env,"diff","--name-only",f"{base_commit}..HEAD").splitlines(),
                      git_before=git_before,git_after=git(project,env,"status","--short"),
                      sessions=sessions,candidate=SNAPSHOT_LABEL,
                      candidate_manifest_sha256=sha(REPO/"manifest.json"))
        json_to(output/"run.json",result)
        print(name,"exit",result["exit"],"seconds",result["seconds"],"sessions",len(sessions),
              "changes",result["changed"],flush=True)


def main():
    global OPS_FIXTURE
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidate",required=True)
    ap.add_argument("--label",required=True)
    ap.add_argument("--jobs",type=int,default=4)
    ap.add_argument("cases",nargs="+")
    args = ap.parse_args()
    assert args.label.isascii() and args.label.replace("-","").isalnum()
    bind_candidate(args.candidate)
    if any(case in OPS for case in args.cases):
        saved_argv = sys.argv[:]
        try:
            sys.argv[1:] = ["release"]
            sim = importlib.util.spec_from_file_location("ops_fixture",REPO/"simulator/behavior.py")
            OPS_FIXTURE = importlib.util.module_from_spec(sim)
            sim.loader.exec_module(OPS_FIXTURE)
            OPS_FIXTURE.release = RELEASE
        finally:
            sys.argv[:] = saved_argv
    behavior = EVIDENCE / args.label
    behavior.mkdir()
    with tempfile.TemporaryDirectory(prefix="sdd-review-execution-") as raw:
        program = Path(raw)/"program"
        shutil.copytree(VENDOR,program)
        (program/"tools").mkdir()
        (program/"tools/python").symlink_to(sys.executable)
        (program/"tools/rg").symlink_to(program/"codex-path/rg")
        (program/"bin/codex").chmod(0o755)
        (program/"bin/codex-code-mode-host").chmod(0o755)
        (program/"codex-path/rg").chmod(0o755)
        (program/"codex-resources/bwrap").chmod(0o755)
        print("Linux CLI", subprocess.run([str(program/"bin/codex"),"--version"],text=True,check=True,capture_output=True).stdout.strip(),flush=True)
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            jobs = {pool.submit(run,name,behavior,program):name for name in args.cases}
            failed = False
            for f in as_completed(jobs):
                try:
                    f.result()
                except Exception as error:
                    failed = True
                    print(jobs[f],type(error).__name__,str(error),flush=True)
    return int(failed)


if __name__ == "__main__":
    raise SystemExit(main())
