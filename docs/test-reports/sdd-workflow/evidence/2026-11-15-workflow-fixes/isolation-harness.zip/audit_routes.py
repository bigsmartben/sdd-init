"""Read retained session traces and check actual caller/recipient relationships."""
from pathlib import Path
import argparse
import json
import re


ROUTED_TOOLS = {'send_message', 'followup_task', 'send_input', 'interrupt_agent', 'close_agent', 'resume_agent'}


def audit(case):
    root = case / 'sessions'
    sections = []
    for path in sorted(root.glob('*.jsonl')):
        rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
        authors = [item['identity'] for item in rows if 'identity' in item]
        sections.append((path, rows, authors))
    agents = {'/root': {'parent': None}}
    aliases = {'/root': '/root'}
    for _, _, identities in sections:
        for identity in identities:
            origin = identity.get('source')
            spawn = origin.get('subagent', {}).get('thread_spawn', {}) if isinstance(origin, dict) else {}
            path = spawn.get('agent_path', '/root')
            if spawn.get('parent_thread_id') and not spawn.get('agent_path'):
                continue
            aliases[identity['id']] = path
            if (nickname := spawn.get('agent_nickname')):
                aliases[nickname] = path
            agents[path] = {'id': identity['id'], 'parent_id': spawn.get('parent_thread_id'),
                            'role': spawn.get('agent_role')}
    for entry in agents.values():
        entry['parent'] = aliases.get(entry.get('parent_id'))

    calls = []
    seen = set()
    for path, rows, identities in sections:
        if not identities:
            continue
        # Mirrored session metadata in a child rollout can repeat the parent.
        # The filename's own session ID identifies the executing stream.
        actor_id = re.search(r'[0-9a-f-]{36}$', path.stem).group()
        if actor_id not in aliases:
            actor_id = identities[0]['id']
        results = {r.get('call_id') for r in rows if r.get('type') == 'function_call_output'}
        for line_no, row in enumerate(rows, 1):
            tool = row.get('name')
            if row.get('type') != 'function_call' or tool not in ROUTED_TOOLS:
                continue
            call_id = row.get('call_id')
            if call_id in seen:
                continue
            seen.add(call_id)
            actor = aliases.get(actor_id)
            args = json.loads(row.get('arguments', '{}'))
            raw = next((args[k] for k in ('target', 'id', 'agent_id') if k in args), None)
            target = aliases.get(raw, raw)
            if raw and target not in agents and not raw.startswith('/'):
                child = f'{actor}/{raw}'
                matches = [a for a in agents if a.rsplit('/', 1)[-1] == raw]
                target = child if child in agents else matches[0] if len(matches) == 1 else None
            relation = 'unknown'
            if actor in agents and target in agents:
                actor_parent = agents[actor]['parent']
                target_parent = agents[target]['parent']
                if actor_parent == target:
                    relation = 'to_caller'
                elif target_parent == actor:
                    relation = 'to_direct_report'
                elif actor_parent and target_parent:
                    relation = 'bypasses_caller'
                elif actor != target:
                    relation = 'bypasses_caller'
            calls.append({'time': row.get('timestamp'), 'actor': actor, 'target': target, 'original_target': raw,
                          'tool': tool, 'relation': relation, 'call_id': row.get('call_id'),
                          'tool_result_recorded': row.get('call_id') in results,
                          'trace': f'sessions/{path.name}', 'line': line_no})
    calls.sort(key=lambda x: x['time'] or '')
    return {'agents': agents, 'calls': calls,
            'bypasses_caller': [r for r in calls if r['relation'] == 'bypasses_caller'],
            'unresolved_targets': [r for r in calls if r['relation'] == 'unknown'],
            'note': 'Call metadata establishes routing, not encrypted message body or delivered outcome.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('case', type=Path, nargs='+')
    parser.add_argument('--save', action='store_true')
    settings = parser.parse_args()
    for case in settings.case:
        data = audit(case)
        if settings.save:
            (case / 'routing-audit.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(case, len(data['calls']), 'calls;', len(data['bypasses_caller']), 'bypasses;',
              len(data['unresolved_targets']), 'unresolved')
