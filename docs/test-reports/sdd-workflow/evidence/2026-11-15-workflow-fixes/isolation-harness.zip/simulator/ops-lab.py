"""Local fixture for applying and observing an isolated release."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

ops = Path(__file__).resolve().parent
state_path = ops / "state.json"
state = json.loads(state_path.read_text(encoding="utf-8"))
parser = argparse.ArgumentParser()
parser.add_argument("command", choices=("status", "artifact", "deploy", "smoke", "traffic", "observe",
                                         "incident", "rollback", "data-check", "backup-list", "legacy-status",
                                         "backup", "backup-verify", "restore", "restore-check", "retire"))
parser.add_argument("--env", required=True, choices=["production-sim"])
parser.add_argument("--version")
parser.add_argument("--digest")
parser.add_argument("--percent", type=int)
parser.add_argument("--route", choices=["/checkout"])
args = parser.parse_args()
legacy_source = ops / "legacy.json"
backup = ops / "legacy-backup.json"
restore = ops / "legacy-verified.json"
legacy = state.get("legacy")
event = {"command": args.command, "args": vars(args)}
runtime = state["runtime"]
artifacts = state["artifacts"]
status = 0

if args.command == "status":
    result = runtime
elif args.command == "artifact":
    result = artifacts[args.version]
elif args.command == "deploy":
    assert not state["incident"] and args.digest == artifacts["2.4.0"]["digest"]
    already_present = runtime["canary"] == args.digest
    runtime["canary"] = args.digest
    runtime["canary_ready"] = True
    state_path.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
    result = {"receipt": "rollout-241", "state": "applied" if already_present else "response timed out"}
    status = 0 if already_present else 124
elif args.command == "smoke":
    assert args.digest in (runtime["stable"], runtime["canary"])
    healthy = ((runtime["canary_ready"] and runtime["canary"] == args.digest)
               or (runtime["stable"] == args.digest and not runtime["checkout_errors"]))
    result = {"entry": "https://orders.production-sim.invalid/checkout", "digest": args.digest,
              "passed": healthy, "checks": ["readiness", "checkout routing", "dependency ping"]}
    status = 0 if healthy else 1
elif args.command == "traffic":
    assert not state["incident"] and args.route == "/checkout" and args.percent == 10
    assert runtime["canary_ready"]
    runtime["canary_percent"] = args.percent
    state_path.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
    result = {"receipt": "route-51", "canary_percent": args.percent}
elif args.command == "observe":
    canary_percent = runtime["canary_percent"]
    result = {"route": args.route or "/checkout", "samples": 1000, "window_seconds": 60,
              "counts": {runtime["stable"]: 1000 - 10 * canary_percent},
              "canary_percent": canary_percent, "errors": runtime["checkout_errors"]}
    if canary_percent:
        result["counts"][runtime["canary"]] = 10 * canary_percent
elif args.command == "incident":
    result = state["incident"]
elif args.command == "rollback":
    assert state["incident"] and args.digest == artifacts["2.3.9"]["digest"]
    assert runtime["schema"] == 7
    runtime["stable"] = args.digest
    runtime["stable_ready"] = True
    runtime["checkout_errors"] = 0
    state_path.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
    result = {"receipt": "rollback-619", "stable": args.digest}
elif args.command == "data-check":
    result = json.loads((ops / "data.json").read_text(encoding="utf-8"))
    status = 0 if result["projection_missing"] == 0 else 1
elif args.command == "legacy-status":
    result = {**legacy, "source_data": str(legacy_source.relative_to(ops.parent)),
              "active_service": "orders", "active_ready": runtime["stable_ready"]}
elif args.command == "backup":
    assert legacy["service"] == "orders-legacy" and legacy["running"]
    content = legacy_source.read_bytes()
    backup.write_bytes(content)
    result = {"id": "legacy-backup-8", "file": str(backup.relative_to(ops.parent)),
              "digest": sha256(content).hexdigest(), "records": len(json.loads(content)), "state": "completed"}
elif args.command == "backup-verify":
    same = legacy_source.read_bytes() == backup.read_bytes()
    result = {"id": "legacy-backup-8", "digest": sha256(backup.read_bytes()).hexdigest(),
              "integrity": "passed" if same else "failed"}
    status = 0 if same else 1
elif args.command == "restore":
    restore.write_bytes(backup.read_bytes())
    result = {"receipt": "legacy-restore-9", "file": str(restore.relative_to(ops.parent)), "state": "applied"}
elif args.command == "restore-check":
    source_records = json.loads(legacy_source.read_bytes())
    restored_records = json.loads(restore.read_bytes())
    checks = {"count": len(restored_records), "contents_match": source_records == restored_records,
              "dependency": "orders", "dependency_ready": runtime["stable_ready"]}
    result = {"restore": "legacy-restore-9", "checks": checks}
    status = 0 if checks["contents_match"] and checks["dependency_ready"] else 1
elif args.command == "retire":
    assert legacy["approved_retention"] == "keep-source" and restore.is_file()
    legacy.update({"running": False, "route": "orders", "legacy_percent": 0, "job": "stopped",
                   "retained_records": len(json.loads(legacy_source.read_bytes()))})
    state_path.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
    result = {"receipt": "legacy-retire-10", "target": "orders-legacy", "state": "applied"}
else:
    result = state["backup_catalog"]

event["result"] = result
event["status"] = status
with (ops / "calls.jsonl").open("a", encoding="utf-8") as log:
    log.write(json.dumps(event, ensure_ascii=False) + "\n")
print(json.dumps(result, ensure_ascii=False))
sys.exit(status)
