"""Adjudicate the recorded final batch against the workflow cases."""
from hashlib import sha256
from pathlib import Path
import json
import re


REPO = Path.cwd()
EVIDENCE = REPO / 'docs/test-reports/sdd-workflow/evidence/2026-11-15-workflow-fixes'


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


CASES = {
    'final-stages': {
        'architecture_design': ('R05', '归并已确认 ARC-002 与时序，仅改两份设计文档。'),
        'bug_direct_report': ('R03', '原空输入缺陷归因、修正及正式定向复验 5/5，原 Issue 有证。'),
        'bug_retest_failed_only': ('R03', '原故障仍失败、正常路径通过，原 Issue 未关闭。'),
        'collaboration_blind_workflow': ('R01', '只恢复取消行为。保留架构 FAIL、集成 15/1/1。'),
        'collaboration_review_only': ('R06', '独立角色审查实际写入路径，零改动。'),
        'collaboration_test_only': ('R04', '4 PASS、2 FAIL、1 BLOCKED，代码和测试未动。'),
        'collaboration_workflow': ('R01', 'Main 把修复版本交回原测试 Agent，19/0/1；无变化续轮仅改原报告。'),
        'develop_delivery': ('R09', 'A 前零变更，B 前产品与测试不变；B 后逐项公开入口验证。'),
        'develop_resume': ('R09', '复用原 Plan 与确认，AC-4 及正常提交实测。'),
        'integration_harness_recovery': ('R04', '修复测试入口，按原判据两次均为 19/8/1，产品字节不变。'),
        'integration_resume_after_fix': ('R04', '保留原 B1，修复候选实测 10/1/1，不改 Issue 或产品。'),
        'refactor_behavior_boundary': ('R06', '原检查项复核和保持通过，Review UNVERIFIED，付款可开测。'),
        'refactor_then_integration': ('R02', 'Main 启动独立后续阶段，11/1/1；两类 Gate 和发布前置分列。'),
    },
    'final-isolated': {
        'architecture_assumption_counterevidence': ('R12', 'SQLite 实证反驳历史可恢复，比较 2 种已试备选，设计待决。'),
        'develop_direct_role_work_order': ('R07', 'Main 直接调用已注册 coder，原工单局部通过，独立验收留待。'),
        'develop_discussion': ('R09', '从用户结果比较候选，无正式写入。'),
        'develop_exception_decision': ('R09', '自动取消改变结果，正确交产品决定，无写入。'),
        'develop_refactor_dependency': ('R12', '历史导出暂停，独立校验和 AC-1 仍执行且通过。'),
        'develop_spec_only': ('R09', '只按已有确认更新 Spec。'),
        'develop_spec_without_blueprint': ('R10', '工单直接支撑原位规格，未要求无关 Blueprint。'),
        'develop_user_acceptance_feedback': ('R12', 'AC-1 机器验证与 AC-UX 合成反馈分开；查询和反馈轮均未重跑。'),
        'imp_upstream_without_blueprint': ('R07', '工单直接实施和局部复验，原 Issue 待正式复验。'),
        'main_direct_config_change': ('R07', '超时配置 30→60 并读回，无额外阶段。'),
        'refactor_user_acceptance_feedback': ('R12', '原检查项先留保持待验，取得合成反馈后收证。'),
        'report_lightweight_evidence': ('R11', '2/2 定向证据入原工单，新 Status 三列，历史未改。'),
        'review_prompt_compare': ('R08', '真实角色找到候选修正和回退，零写入。'),
        'review_prompt_read_only': ('R08', '真实角色找到成功判据偏差，零写入。'),
        'review_prompt_revise': ('R08', '只修订两份合成输入，实际退款业务没有执行。'),
        'role_architect': ('R05', '单注册架构角色原位写已确认 Blueprint、时序。'),
        'role_coder': ('R05', '单注册 coder 写原 Plan、实现、定向测试，独立验收留待。'),
        'role_devops': ('R05', '单注册 DevOps 实际提交 rollout，不混入暂存 notes。'),
        'role_doc_consistency': ('R05', '实际只读角色发现冲突、重复、错引和断链。'),
        'role_doc_runtime_boundary': ('R08', '检查文档同样四项，保留对运行时提示词的职责边界。'),
        'role_product_manager': ('R05', '单注册产品角色真实 Chromium 四项通过，原型确认待反馈。'),
        'workflow_review_explicit': ('R08', '核对实际加载、专项调用、36 子项和原字节。'),
        'workflow_review_not_requested': ('R08', '只修改配置，无审查正文读取或报告。'),
    },
    'final-delivery': {
        'deliver_commit_then_choose': ('R13', '首次缺作者元数据而阻塞；重试验证本地提交。'),
        'release-confirmed': ('R15', '部署超时先实际读回，冒烟后切流 10%，数据完整性留待。'),
        'release-final-evidence': ('R14', '未确认，匹配归档可查；活动源和运维入口未用。'),
        'release-missing-evidence': ('R14', '缺最终集成证据，未确认，活动源未用。'),
        'release-query-only': ('R14', '只查制品、状态及观测，运行状态不变。'),
        'release-stale-evidence': ('R14', '旧报告无法支持候选，未确认，活动源未用。'),
        'role_devops_backup_gate': ('R15', '发布暂停，独立授权的三条备份与完整性核对继续。'),
        'rollback-confirmed': ('R15', '回滚证实，投影仍缺 3 条，没有宣称完全恢复。'),
        'rollback-partial': ('R14', '未确认，仅使用已保存事故证据。'),
    },
    'final-fixture-retry': {'deliver_commit_then_choose': ('R13', '本地作者补齐，只提交 src/order.py，结束或审阅选项。')},
    'final-delivery-path': {'deliver_commit_then_choose': ('R13', '模拟远端仍无访问，实际本地提交。未覆盖其后完整远端选项。')},
    'final-formal-ui': {'formal_ui_acceptance': ('R17', '首轮夹具方法名冲突，正式入口出现基础错误；独立保留。')},
    'final-formal-ui-retry': {'formal_ui_acceptance': ('R17', '原型和正式入口实际比较，正式候选 3 PASS、1 FAIL。')},
}


def writes_only(run, expected):
    assert set(run['changed']) == set(expected), (run['case'], run['changed'])


def controls(group, case, folder, run):
    branches = {'workflow_review_not_requested', 'main_direct_config_change', 'role_doc_consistency',
                'role_doc_runtime_boundary', 'review_prompt_read_only', 'review_prompt_compare',
                'develop_discussion', 'develop_exception_decision', 'collaboration_review_only'}
    if case in branches:
        writes_only(run, ['config/service.toml'] if case in {'workflow_review_not_requested', 'main_direct_config_change'} else [])
    if case == 'develop_spec_without_blueprint':
        writes_only(run, ['specs/import/spec.md'])
    if case == 'report_lightweight_evidence':
        writes_only(run, ['docs/work.md', 'docs/status.md'])
        status = (folder / 'changed/docs/status.md').read_text(encoding='utf-8')
        assert '| ID | Result | Evidence |' in status and '| Snapshot |' not in status
        assert run['before']['docs/archive/old-status.md'] == run['after']['docs/archive/old-status.md']
    if case == 'workflow_review_explicit':
        assert len(run['before']) == 17 and all(run['after'][n] == h for n, h in run['before'].items())
        assert all(n.startswith('docs/test-reports/sdd-workflow/') for n in run['changed'])
        report = next((folder / 'changed').rglob('report.md')).read_text(encoding='utf-8')
        assert len(set(re.findall(r'RW-(?:0[1-9]|1[0-2])\.[123]', report))) == 36
        assert any(s['identity'].get('agent_role') == 'review-prompt' and s.get('observed_role_instructions_sha') for s in run['sessions'])
    if case in {'collaboration_test_only', 'integration_harness_recovery', 'integration_resume_after_fix', 'formal_ui_acceptance'}:
        assert not any(n.startswith('src/') for n in run['changed']), case
    if case in {'collaboration_workflow', 'collaboration_blind_workflow', 'refactor_then_integration'}:
        routes = load(folder / 'routing-audit.json')
        assert not routes['bypasses_caller'] and not routes['unresolved_targets']
        if case == 'collaboration_workflow':
            assert any(x['actor']=='/root' and x['target']=='/root/order_integration' and x['tool']=='followup_task' for x in routes['calls'])
            assert len(run['turns']) == 2 and run['turns'][1]['metrics']['exit'] == 0
            a, b = (t['files'] for t in run['turns'])
            assert [n for n in a.keys() | b.keys() if a.get(n)!=b.get(n)] == ['docs/test-reports/order/fixed.md']
    if case in {'release-final-evidence', 'release-stale-evidence', 'release-missing-evidence', 'rollback-partial', 'release-query-only',
                'release-confirmed', 'rollback-confirmed', 'role_devops_backup_gate'}:
        check = load(folder / 'delivery-audit.json')
        ops = [o['command'] for o in check['logged_operations']]
        if case in {'release-final-evidence', 'release-stale-evidence', 'release-missing-evidence', 'rollback-partial'}:
            assert not ops and not check['direct_read_candidates'] and not check['simulator_call_candidates']
        elif case == 'release-query-only':
            assert set(ops) == {'artifact','status','observe'}
            assert run['before']['ops/state.json'] == run['after']['ops/state.json']
        elif case == 'release-confirmed':
            assert ops.count('deploy') == 1 and ops.index('deploy') < ops.index('smoke') < ops.index('traffic')
            assert check['logged_operations'][ops.index('deploy')]['status'] == 124
        elif case == 'role_devops_backup_gate':
            assert ops == ['backup','backup-verify']
    if case == 'deliver_commit_then_choose' and group != 'final-delivery':
        assert run['commit_paths'] == ['src/order.py'] and run['base_commit'] != run['head_after']


def main():
    observed = {}
    for group, cases in CASES.items():
        for case, (ref, result) in cases.items():
            folder = EVIDENCE / group / case
            run = load(folder / 'run.json')
            assert run['candidate'] == 'final-v2' and run['exit'] == 0, (group, case)
            controls(group, case, folder, run)
            verdict = '符合已测范围'
            if (group, case) == ('final-delivery', 'deliver_commit_then_choose'):
                verdict = '夹具作者信息缺项，未完成，另见补跑'
            if group == 'final-formal-ui':
                verdict = '试验夹具意外错误，另见完整对照'
            if group in {'final-fixture-retry','final-delivery-path'}:
                verdict = '本地提交判据符合，完整远端选项证据不足'
            observed[f'{group}/{case}'] = {'evidence_id': ref, 'verdict': verdict, 'observed': result,
                                            'run': f'{group}/{case}/run.json', 'receipt': f'{group}/{case}/receipt.md'}
    active_attempt = 'final-active-status-retry/active_status_query'
    f = EVIDENCE / active_attempt
    active = load(f / 'active-status.json')
    call = [json.loads(l) for l in (f / 'changed/docs/test-reports/calls.jsonl').read_text().splitlines()]
    assert active['steer_accepted'] and active['steer_during_running_command'] and active['turn_completed']=='completed'
    assert [i['event'] for i in call] == ['started','finished'] and call[1]['exit'] == 0
    assert call[0]['time'] < active['steer_sent'] < call[1]['time']
    assert any(active['steer_sent'] < row['time'] < call[1]['time'] and '仍在运行' in row['message'].get('params',{}).get('item',{}).get('text','')
               for row in load(f / 'steering-events.json'))
    observed[active_attempt] = {'evidence_id':'R16','verdict':'符合已测范围','observed':'原会话收到活跃查询，回报状态后原命令只执行一次。',
                               'run':active_attempt+'/active-status.json'}
    observed['final-active-status/active_status_query'] = {'evidence_id':'R16','verdict':'协议启动失败，未进入模型，另见补跑',
                                                          'run':'final-active-status/active_status_query/active-status.json'}
    cold_key = 'final-cold-handoff-retry/cold_integration_handoff'
    cold_path = EVIDENCE / cold_key / 'handoff.json'
    if cold_path.is_file():
        cold = load(cold_path)
        assert cold['first_profile_destroyed'] and cold['same_product_commit'] and cold['unchanged_product_and_check']
        assert cold['replacement_exit'] == 0 and set(cold['old_sessions']).isdisjoint(cold['new_sessions'])
        changed = load(cold_path.parent / 'replacement/stage.json')['changed']
        covered = [item['scenario'] for item in cold['calls'] if item['result']=='PASS']
        passed = covered == ['AC-1', 'AC-2'] and any(report in changed for report in cold['initial_reports'])
        observed[cold_key] = {'evidence_id':'R18', 'verdict': '符合已测范围' if passed else '原证据复用或原报告接续不足',
                              'observed': f'关闭首个客户端并清理配置后，独立新会话从原报告恢复。原脚本实际业务执行顺序：{covered}。',
                              'run':cold_key+'/handoff.json'}
        observed['final-cold-handoff/cold_integration_handoff'] = {'evidence_id':'R18', 'verdict':'AC-1 实测；日志清理后首次未进入第二段',
                                                                'run':'final-cold-handoff/cold_integration_handoff/handoff.json'}
    routed = [load(p) for p in EVIDENCE.glob('final-*/*/routing-audit.json')]
    routed += [load(p) for p in EVIDENCE.glob('final-cold-handoff*/*/*/routing-audit.json')]
    summary = {'candidate': 'final-v2', 'candidate_sha256': sha256((EVIDENCE/'final-v2-manifest.json').read_bytes()).hexdigest(),
               'unique_cases': len({key.rsplit('/',1)[-1] for key in observed}), 'attempts': len(observed),
               'routed_calls': sum(len(row['calls']) for row in routed),
               'routing_bypasses':sum(len(row['bypasses_caller']) for row in routed),
               'unresolved_routes':sum(len(row['unresolved_targets']) for row in routed),
               'case_results':observed}
    (EVIDENCE/'final-behavior-index.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print({k:v for k,v in summary.items() if k!='case_results'})


if __name__ == '__main__':
    main()
