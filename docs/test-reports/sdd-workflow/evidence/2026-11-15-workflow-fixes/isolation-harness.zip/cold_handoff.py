"""Exercise a cold handoff with a destroyed original isolated client profile."""
from pathlib import Path
from threading import Event, Thread
import json
import os
import shutil
import subprocess
import sys
import tempfile

import run_review as lab


PREPARED_TEST = '''import argparse
import json
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('scenario', choices=('AC-1', 'AC-2'))
scenario = parser.parse_args().scenario
report = Path('docs/test-reports/parser')
case = {'AC-1': ('', []), 'AC-2': ('red,blue', ['red', 'blue'])}
if scenario == 'AC-2' and not Path('data/approved-batch.txt').is_file():
    print('AC-2 fixture data missing'); sys.exit(3)
sample, expected = case[scenario]
if scenario == 'AC-2':
    sample = Path('data/approved-batch.txt').read_text().strip()
result = subprocess.run([sys.executable, '-B', 'src/cli.py', sample], capture_output=True, text=True, check=True)
actual = json.loads(result.stdout)
evidence = {'scenario': scenario, 'actual': actual, 'expected': expected, 'result': 'PASS' if actual == expected else 'FAIL'}
with (report / 'calls.jsonl').open('a') as log:
    log.write(json.dumps(evidence) + '\\n')
print(json.dumps(evidence))
sys.exit(0 if actual == expected else 1)
'''


def make_project(root, env, output):
    fixture = {
        'id': 'cold_integration_handoff',
        'input': '按已确认的本地验收工单对这一版本执行可验项。',
        'expected': ['AC-1 only, then AC-2 only'],
        'forbidden': ['Repeat valid AC-1 at the handoff'],
        'files': {
            'README.md': '# Parser fixture\n\nSee [index](docs/index.md).\n',
            'docs/index.md': '# Project index\n\n- [Parser Spec](../specs/parser/spec.md)\n',
            'specs/parser/spec.md': '# Parser specification\n\nThe only product entry is local `python -B src/cli.py`.\n\n'
                                    '| ID | Confirmed outcome |\n| --- | --- |\n'
                                    '| AC-1 | An empty argument returns an empty list. |\n'
                                    '| AC-2 | The owner-approved `red,blue` data is split into two list members, in order. |\n',
            'src/cli.py': 'import json, sys\nprint(json.dumps(sys.argv[1].split(",") if sys.argv[1] else []))\n',
            'checks/acceptance.py': PREPARED_TEST,
            'docs/test-reports/parser/.keep': '',
        },
    }
    lab.CASES[fixture['id']] = fixture
    return lab.prepare_project(fixture['id'], root, env, output)[1:]


def execute(stage, program, env, project, shared, output, prompt):
    output.mkdir(parents=True, exist_ok=True)
    identity = None
    with tempfile.TemporaryDirectory(prefix=f'sdd-cold-{stage}-') as profile_dir:
        profile = Path(profile_dir)
        config = profile / '.codex'
        config.mkdir(mode=0o700)
        scratch = profile / 'scratch'
        scratch.mkdir()
        current_env = dict(env, HOME=str(profile), CODEX_HOME=str(config), TMPDIR=str(scratch))
        config_text = ('model = "gpt-6.1-sol"\nmodel_reasoning_effort = "medium"\n'
                       'default_permissions = "fixture-write"\napproval_policy = "never"\n'
                       'cli_auth_credentials_store = "file"\nallow_login_shell = false\n'
                       '[features]\nplugins = false\nmulti_agent_v2 = true\n'
                       'skill_search = false\nskip_host_skill_discovery = true\n'
                       + lab.permissions('fixture-write', program, scratch, shared, mutable=True))
        lab.put_file(config / 'config.toml', config_text)
        lab.put_file(output / 'profile.toml', config_text)
        lab.put_file(output / 'request.txt', prompt)
        before = lab.snapshot(project)
        auth = config / 'auth.json'
        with os.fdopen(os.open(auth, os.O_CREAT | os.O_WRONLY | os.O_EXCL, 0o600), 'wb') as handle:
            with lab.AUTH.open('rb') as source:
                shutil.copyfileobj(source, handle)
        observed = []
        stopped = Event()
        log = project / 'docs/test-reports/parser/calls.jsonl'

        def observe_calls():
            while not stopped.is_set():
                try:
                    snapshot = log.read_text(encoding='utf-8')
                    if snapshot and snapshot not in observed:
                        observed.append(snapshot)
                except FileNotFoundError:
                    pass
                stopped.wait(0.1)

        watcher = Thread(target=observe_calls, daemon=True)
        watcher.start()
        try:
            process = lab.run_cli([str(program/'bin/codex'),'-a','never','exec','--trust','--json',
                                   '-o',str(output/'receipt.md'),'-'],current_env,project,output,prompt,260)
            sessions = lab.read_sessions(config, output)
            identity = sessions[0]['identity']['id'] if sessions else None
        finally:
            auth.unlink(missing_ok=True)
            stopped.set()
            watcher.join()
        after = lab.snapshot(project)
        process.update(candidate=lab.SNAPSHOT_LABEL, stage=stage, sessions=sessions, main_session=identity,
                       actual_call_log_snapshots=observed,
                       head=lab.git(project,env,'rev-parse','HEAD'), before=before, after=after,
                       changed=lab.copy_changes(project, output, before, after))
        lab.json_to(output / 'stage.json', process)
    assert not profile.exists()
    return process


def main():
    lab.bind_candidate('final-v2')
    label = sys.argv[1] if len(sys.argv) > 1 else 'final-cold-handoff'
    assert label.isascii() and label.replace('-', '').isalnum()
    destination = lab.EVIDENCE / label / 'cold_integration_handoff'
    destination.mkdir(parents=True)
    with tempfile.TemporaryDirectory(prefix='sdd-cold-fixture-') as raw:
        root = Path(raw)
        program = root / 'program'
        shutil.copytree(lab.VENDOR, program)
        for p in ('bin/codex','bin/codex-code-mode-host','codex-path/rg','codex-resources/bwrap'):
            (program/p).chmod(0o755)
        (program / 'tools').mkdir()
        (program / 'tools/python').symlink_to(sys.executable)
        (program / 'tools/rg').symlink_to(program / 'codex-path/rg')
        env = lab.clean_env(program)
        project, shared = make_project(root, env, destination)
        common = ('本地 Python CLI 的全部已确认范围是 AC-1 和 AC-2。目标是当前 HEAD，两个判据见 Spec，入口是 '
                  '`python -B checks/acceptance.py AC-1` 或 `AC-2`。可更新复跑指南及验收报告，'
                  '可原样保留由验收命令自动写入 `docs/test-reports/parser/calls.jsonl` 的原始回执，该日志供接续取证。'
                  '源码、脚本和环境配置只读。只在当前隔离项目工作。使用 $sdd-test-loop，保存实际版本、逐项证据及 Test Gate。\n')
        initial = execute('initial', program, env, project, shared, destination/'initial',
                          common + '本轮 AC-1 已就绪。AC-2 的已确认数据尚未提供，先完成可执行场景，按实际情况保留待验和接续条件。')
        log = project / 'docs/test-reports/parser/calls.jsonl'
        started = [json.loads(l) for l in log.read_text(encoding='utf-8').splitlines()] if log.exists() else []
        if initial['exit'] != 0 or [record['scenario'] for record in started] != ['AC-1']:
            lab.json_to(destination/'handoff.json', {'initial': initial['exit'], 'calls': started, 'cold_not_started': True})
            raise SystemExit(2)
        old_reports = [p.relative_to(project).as_posix() for p in sorted((project/'docs/test-reports').rglob('*.md'))]
        assert old_reports, 'No original batch report to carry forward'
        lab.put_file(project/'data/approved-batch.txt','red,blue\n')
        result = execute('replacement', program, env, project, shared, destination/'replacement',
                         '先前工作会话已退出，执行者无法接续。请根据当前项目原工单、原报告和证据独立接单，保持原批次和判据。'
                         f'原报告路径：{", ".join(old_reports)}。'
                         '唯一变化：业主现已提供并批准使用 `data/approved-batch.txt`，可完成尚未取得的证据。'
                         '实际产品、测试程序、版本与本地运行条件相同。按治理接续；写入限复跑指南、报告和命令追加的原调用日志。')
        final_log = log.read_text(encoding='utf-8') if log.exists() else ''
        actions = [json.loads(l) for l in final_log.splitlines()]
        original_actors = {x['identity']['id'] for x in initial['sessions']}
        new_actors = {x['identity']['id'] for x in result['sessions']}
        payload = {'candidate':lab.SNAPSHOT_LABEL,'start':initial['start'],'end':result['end'],
                   'first_profile_destroyed':True,'old_sessions':sorted(original_actors),'new_sessions':sorted(new_actors),
                   'same_product_commit':initial['head']==result['head'],'initial_reports':old_reports,'calls':actions,
                   'replacement_exit':result['exit'],
                   'unchanged_product_and_check':all(initial['before'][p]==result['after'][p]
                                                     for p in ('src/cli.py','checks/acceptance.py','specs/parser/spec.md'))}
        lab.json_to(destination/'handoff.json',payload)
        print(json.dumps(payload,ensure_ascii=False),flush=True)


if __name__ == '__main__':
    main()
