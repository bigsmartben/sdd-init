# T001 local acceptance

Confirmed scope: execute this fixture’s local parser checks and record actual version, results and evidence here. Run `python -B checks/active_acceptance.py` once for the actual evidence; the normal test window is 70 seconds. No parser, test or acceptance criteria changes are authorized.
