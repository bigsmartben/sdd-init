def parse(value):
    return value.split(',') if value else []
