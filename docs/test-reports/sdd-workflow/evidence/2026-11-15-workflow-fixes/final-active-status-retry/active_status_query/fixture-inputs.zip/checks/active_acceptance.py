import json
from pathlib import Path
import subprocess
import sys
import time

receipt = Path('docs/test-reports/local-verification.json')
receipt.parent.mkdir(parents=True, exist_ok=True)
with Path('docs/test-reports/calls.jsonl').open('a') as log:
    log.write(json.dumps({'event': 'started', 'time': time.time()}) + '\n')
time.sleep(70)
result = subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-v'],
                        capture_output=True, text=True)
receipt.write_text(json.dumps({'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}) + '\n')
with Path('docs/test-reports/calls.jsonl').open('a') as log:
    log.write(json.dumps({'event': 'finished', 'time': time.time(), 'exit': result.returncode}) + '\n')
print(receipt.read_text())
sys.exit(result.returncode)
