from unittest import TestCase
from src.parser import parse

class ParserTest(TestCase):
    def test_empty(self):
        self.assertEqual(parse(''), [])

    def test_split(self):
        self.assertEqual(parse('one,two'), ['one', 'two'])
