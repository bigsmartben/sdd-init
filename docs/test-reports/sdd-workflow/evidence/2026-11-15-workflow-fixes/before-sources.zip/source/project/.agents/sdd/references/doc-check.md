# 文档校验 CLI

统一入口为项目内 `.agents/skills/sdd-workflow/sdd/scripts/doc_check.py`，Python 3.11+，仅依赖标准库，只读、不访问网络、不更新状态或 Gate。写入者执行机械检查并完成语义核对。

## 使用

从项目根目录执行，显式传入本次修改和直接受影响的文件或目录：

```powershell
python -B .agents/skills/sdd-workflow/sdd/scripts/doc_check.py --root . specs/payment/spec.md docs/blueprint.md
python -B .agents/skills/sdd-workflow/sdd/scripts/doc_check.py --root . --format json docs/test-reports
```

路径相对 `--root` 解析，也可传入根目录内的绝对路径。目录递归选择 `.md`，排除 `.git`、`.build`、`node_modules`、`.venv`、`__pycache__`；文件去重。范围为空、文件不存在、非 Markdown 文件或路径越出根目录均报错。直接检查的文件和目录必须位于根目录内。运行项目已接入的 `.agents/skills/sdd-workflow/sdd/scripts/doc_check.py` 时，允许解析经该共享入口指向同一共享根内的 Markdown。核对托管导航可运行 `python -B .agents/skills/sdd-workflow/sdd/scripts/doc_check.py --root . AGENTS.md`。链接检查只核对存在性及锚点；反向引用按本次变更显式纳入。

文本结果逐项输出 `文件:行号: 级别 规则码: 问题`。JSON 包含 `schema_version`、`scope=mechanical_only`、`files`、`diagnostics`、`errors` 和 `warnings`。行号从 1 开始，文件诊断使用项目相对路径；根目录外的输入显示实际路径。

退出码：`0` 表示无机械错误，仍可能有警告；`1` 表示存在错误，或使用 `--strict` 时存在警告；`2` 表示命令参数错误。默认不启用 strict，不将需要人工判断的警告自动变成项目门禁。

## 按章节读取

`--read` 接受一个或多个 `文件#标题锚点`。输出该标题及其正文，到下一个标题为止。标题前的独立 `<a id="...">` 或 `<a name="...">` 空锚点可作为同一章节的别名。需要选取表格行时追加 `:首列值`，多行用逗号分隔。保留该节正文、表头和匹配行。路径与锚点超出支持范围或选定行不存在时返回错误，供调用者核对选择器。读取模式不执行文档检查。

## 检查范围

| 规则 | 机械检查 | 默认级别 |
|---|---|---|
| DOC000 | 输入缺失、越界、类型错误或未选择任何 Markdown | 错误 |
| DOC001 | 无法读取 UTF-8、非法编码或 NUL；允许 UTF-8 BOM 和 CRLF | 错误 |
| DOC002 | 顶层反引号／波浪线代码围栏或文件头 YAML 未闭合 | 错误 |
| DOC003 | ATX／Setext 标题层级跳跃；不强制首标题 H1 | 警告 |
| DOC004 | 具有标准分隔行的管道表格列数不一致；转义及行内代码中的竖线不计列 | 错误 |
| DOC005 | 同一文件中的 FR／AC／ARC／PUC／PAC／PENV 或 T001 类编号重复声明 | 错误 |
| DOC006 | 已识别单行链接的目标不合法或不在支持的目标语法内 | 错误 |
| DOC007 | 本地目标不存在或越出根目录 | 错误 |
| DOC008 | 本地 Markdown 目标不存在对应标题锚点或显式 HTML id/name | 错误 |
| DOC009 | 全式／折叠式引用链接缺少定义，或引用标签重复定义 | 错误 |
| DOC010 | 模板路径占位符或非 Markdown 文件的 fragment 未检查 | 警告 |

编号声明限于列表或标题起始的 `FR-001:` / `T001：` 形式，以及首列表头为 `ID` 的定义表首列；含 `Result`、`Evidence`、`Snapshot` 的结果表不作为声明。正文提及编号不视为声明；跨文档引用是否对应同一语义、编号是否在迁移中稳定由 Agent 核对。

链接支持常用单行内联链接／图片、全式与折叠式引用链接和单行引用定义；支持百分号编码、尖括号包裹的含空格路径、平衡括号路径及引号标题。远程 URL、mailto 等不访问也不判可达；站点根路径不推定为项目根路径。Markdown 标题锚点采用 Unicode 字母／数字、空格转连字符及重复标题后缀 `-1`、`-2`；支持显式 HTML id/name。

## 判断边界

这是有限 Markdown 子集检查，不是完整 CommonMark/GFM 渲染器或格式化器。代码围栏、缩进代码、行内代码、文件头 YAML 和 HTML 注释中的示例不作为正文链接或编号。多行链接、复杂嵌套标签、引用式短链接的歧义、嵌套容器内语法、HTML 内部结构及站点特有锚点规则不保证覆盖，使用这些语法时由 Agent 或项目已有渲染器补查并报告未检查范围。不强制所有模板章节、不验证远程预览访问、不根据关键词推定业务覆盖。

Agent 仍负责术语一致性、权威归属、上下游约束、有效例外、迁移语义承接、引用是否真正支持结论、证据充分性及任务范围。报告必须区分机械结果和语义结论；退出 0 不代表文档语义正确、设计已确认或实现／验收通过。诊断不授权改变要求或批量改写历史记录。
